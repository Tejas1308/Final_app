from flet import *
import datetime
import csv
import os

"""DEFAULT_FLET_PATH = ''  # or 'ui/path'
DEFAULT_FLET_PORT = 8502"""

Lst = list()
txt_name=["","","","","","",""]

i = 0
current_question = 0
lst = [7,4,3,4,3,3,3,4,4,2,3,3,3,3,0]
score = 0.0

def main(page: Page):
    page.theme_mode = "dark"
    page.window_height=755
    page.window_width=500
    page.window_resizable=False
    page.update()

    page.title = "Know your spiritual age"
    
    def btn_click(e):
        #page.add(txt_name)

      Lst = []
      for i in range(len(l)):
        if not txt_name[i].value :
            txt_name[i].error_text = "Please enter your "+l[i]
        else:
            name = txt_name[i].value

            if i == 0 :
               if all(chr.isalpha() or chr.isspace() for chr in name) == True:
               #if name.isalpha() == True:
                  Lst.append(name)
                  txt_name[i].error_text = ""
               else:
                  txt_name[i].error_text = "Please enter a valid name"

            elif i == 1:
               if name.isdigit() == True and len(name) == 10:
                Lst.append(name)
                txt_name[i].error_text = ""
               else:
                 txt_name[i].error_text = "Please enter a valid phone number" 
            elif i == 2:
               Lst.append(name)
               txt_name[i].error_text = ""
            elif i == 3:
               if name.isdigit == True and int(name)>=10 or int(name)<=100:
                  Lst.append(name)
                  txt_name[i].error_text = ""
               else:
                   txt_name[i].error_text = "Please enter a valid age" 
            
            elif i == 5 or i == 4:
        
                  Lst.append(name)
                  txt_name[i].error_text = ""
               #else:
                   #txt_name[i].error_text = "Please enter a valid age" 
            
            elif i == 6:
               while True:
                    try:
                        day, month, year = name.split('/')
                        datetime.datetime(int(year), int(month), int(day))
                        txt_name[i].error_text = ""
                        break

                    except ValueError:
                        txt_name[i].error_text = "Please enter a valid date" 
        print(Lst)
        page.update()

      flag = True
      for i in range(len(l)):
           #print(txt_name[i].error_text +""+str(i))
           if txt_name[i].error_text != "":
              flag = False
              btn_click    
                      
      if flag == True:
           page.on_route_change = route_change
           page.on_view_pop = view_pop
           page.go(page.route)

    page.title = "Start Page"

    l = ["name","phone number","gender (M/F)","age (between 10 and 100)", "qualification/profession","address","Brahm Gyan Deeksha date(DD/MM/YYYY)"]
    
   
    for j in range(len(l)):
       if j == 2:
          txt_name[j] = RadioGroup(content=Row([
            Radio(value="male", label="Male"),
            Radio(value="female", label="Female")]))
          
       else:
        txt_name[j] = TextField(label="Your "+l[j])
    
    def route_change(route):
        global current_question
        
        page.views.clear()

        pb = ProgressBar(width=400)

        def button_clicked(e):
            page.go("/" + str(e))
            global score
            if e.control.data in choices:
                ans = choices.index(e.control.data)
                score+=float(myScores[ans])
                Lst.append(f'{chr(ord("A") + ans)}')

        choices = [questions[current_question][f'Choice {chr(ord("A") + i + j)}'] for j in range(lst[current_question])]
        myScores = [questions[current_question][f'Score {chr(ord("A") + i + j)}'] for j in range(lst[current_question])]
        
        dlg = AlertDialog(
        title=Text("Your spiritual age is "+str(score)+ "!"), on_dismiss=lambda e: print("Dialog dismissed!"))

        def open_dlg(e):
            page.dialog = dlg
            dlg.open = True
            page.update()
        
        page.views.append(
                View(
                    "/",
                    [            
                        ElevatedButton("Start Quiz", on_click=lambda _: page.go("/0"))
                    ],
                )
            )        

        page.views.append(
                View(
                    "/0",
                    [
                           AppBar(title=Text("Know your spiritual age"), bgcolor=colors.SURFACE_VARIANT),
                            # Question label
                            Text(questions[current_question]['Question']),                
                            *[ElevatedButton(text=choice, on_click=button_clicked, data= choice) for choice in choices],
                            Column([Text(""), pb])

                        ],
                        )
                        )


        num_questions = len(questions)
        for k in range(1,num_questions+1 ):
            pb.value = current_question/(num_questions-2)
            choices = [questions[current_question][f'Choice {chr(ord("A") + i + j)}'] for j in range(lst[current_question])]
            
            if page.route == "/"+str(k):
                page.views.append(
                    View(
                        "/"+str(k),
                        [
                            AppBar(title=Text("Know your spiritual age"), bgcolor=colors.SURFACE_VARIANT),
                            # Question label
                            Text(questions[current_question]['Question']),                
                            *[ElevatedButton(text=choice,on_click=button_clicked, data=choice) for choice in choices],                            
                            Column([Text(""), pb])
                        ],
                    )
                )                            
        current_question +=1        
        if current_question == num_questions:
            page.views.append(
                View(
                    "/"+str(num_questions),
                    [
                        AppBar(title=Text("Know your spiritual age"), bgcolor=colors.SURFACE_VARIANT),
                        Text("Jai Maharaj Ji"),   

                    ],
                )
            ) 

            if score > 0 :
             Lst.append(score) # add current date and time
             with open('answers.csv', mode = 'a',newline='', encoding='utf-8') as f:
                Write = csv.writer(f)
                Write.writerow(Lst)
            open_dlg(None)


        page.update()    
        print(score)
        

    def view_pop(view):
        page.views.pop()
        top_view = page.views[-1]
        page.go(top_view.route)
    
    b = ElevatedButton(text='Start Quiz', on_click=btn_click)
    page.add(txt_name[0],txt_name[1],Text("Your gender (M/F):"), txt_name[2],txt_name[3],txt_name[4],txt_name[5],txt_name[6],b)
   
        # Read questions from the csv file
with open('questions.csv', newline='', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    questions = list(reader)
    
"""if __name__ == "__main__":
    flet_path = os.getenv("FLET_PATH", DEFAULT_FLET_PATH)
    flet_port = int(os.getenv("FLET_PORT", DEFAULT_FLET_PORT))
    app(name=flet_path, target=main, view=None, port=flet_port)"""

#app(target=main, view=WEB_BROWSER, port = 56940)
app(target=main,view=WEB_BROWSER)

